#!/bin/bash
set -e

SOURCE_FILE="gen_W3_CNC_SDL_400_RevA.cpp"
TARGET_BIN="run_wok_cnc_saddle_builder"
OUTPUT_STEP="W3-CNC-SDL-400_RevA.STEP"

echo "=== [WOK COMPILER] Building W3-CNC-SDL-400_RevA ==="

# 动态查找 OpenCASCADE 头文件与库路径
OCC_INCLUDE=$(find /usr/include -type d -name "opencascade" 2>/dev/null | head -n 1)
if [ -z "$OCC_INCLUDE" ]; then
    OCC_INCLUDE="/usr/include/opencascade"
fi

OCC_LIB="/usr/lib/x86_64-linux-gnu"

g++ -O3 -std=c++17 \
    -I${OCC_INCLUDE} \
    ${SOURCE_FILE} \
    -L${OCC_LIB} \
    -lTKernel -lTKMath -lTKG2d -lTKG3d -lTKGeomBase -lTKGeomAlgo \
    -lTKBRep -lTKTopAlgo -lTKPrim -lTKBO -lTKBool -lTKFillet -lTKSTEP -lTKXSBase \
    -o ${TARGET_BIN}

chmod +x ${TARGET_BIN}
./${TARGET_BIN} ${OUTPUT_STEP}

echo "=== [SUCCESS] Output generated at /mnt/c/Wolff3D_CAD/W3_CNC_SDL_400_RevA/${OUTPUT_STEP} ==="