#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

TARGET_SRC="gen_W1_AERO_SAT_ADP_350_RevA.cpp"
TARGET_BIN="run_wok_aero_sat_builder"
OUTPUT_STEP="W1-AERO-SAT-ADP-350_RevA.STEP"

echo "=========================================================="
echo "[+] Initializing Build Pipeline for Taxonomy 2.1"
echo "=========================================================="

OCCT_INC="/usr/include/opencascade"
CXX="g++"
CXXFLAGS="-O3 -std=c++17 -Wall -Wextra"
INCLUDES="-I${OCCT_INC}"
LIBS="-lTKernel -lTKMath -lTKG2d -lTKG3d -lTKGeomBase -lTKBRep -lTKTopAlgo -lTKPrim -lTKBO -lTKBool -lTKFillet -lTKShHealing -lTKSTEP -lTKSTEPBase -lTKSTEPAttr -lTKXSBase"

echo "[+] Compiling C++ parametric geometry kernel..."
${CXX} ${CXXFLAGS} ${INCLUDES} "${TARGET_SRC}" -o "${TARGET_BIN}" ${LIBS}

echo "[+] Executing geometry kernel to generate STEP entity..."
./"${TARGET_BIN}" "${OUTPUT_STEP}"

if [ -f "${OUTPUT_STEP}" ] && [ -s "${OUTPUT_STEP}" ]; then
    STEP_SIZE=$(wc -c < "${OUTPUT_STEP}")
    STEP_HASH=$(sha256sum "${OUTPUT_STEP}" | awk '{print $1}')
    echo "[ASSET] 3D CAD STEP MODEL"
    echo "  File : ${OUTPUT_STEP}"
    echo "  Size : ${STEP_SIZE} bytes"
    echo "  Hash : ${STEP_HASH}"
fi

echo "[SUCCESS] Pipeline for W1-AERO-SAT-ADP-350_RevA completed."